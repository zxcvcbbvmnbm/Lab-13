interface EdgeWithWeightFunctions
{
	public int getFromVertex();	
	public int getToVertex();
	public double getWeight();
	public String toString();
}
