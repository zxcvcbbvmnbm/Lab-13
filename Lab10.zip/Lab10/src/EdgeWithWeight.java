import java.util.Objects;

class EdgeWithWeight implements EdgeWithWeightFunctions {
    
    private int from_vertex;
    private int to_vertex;
    private double weight;
    
    EdgeWithWeight(int from, int to, double w){
        from_vertex = from;
        to_vertex = to;
        weight = w;
    }
    
    public int getFromVertex(){
        return from_vertex;
    }
    
    public int getToVertex(){
        return to_vertex;
    }
    
    public double getWeight(){
        return weight;
    }
    
    public String toString(){
        return "(" + from_vertex + "," + to_vertex + "," + weight + ")";
    }
    
    @Override
    public boolean equals(Object obj){
        
        if (this == obj) return true;
        if (obj == null) return false;
        
        if (obj instanceof EdgeWithWeight){
            
            EdgeWithWeight otherEdge = (EdgeWithWeight) obj;
            
            if ((from_vertex == otherEdge.from_vertex) && (to_vertex == otherEdge.to_vertex))
                return true;
        }
        
        return false;
        
    }
    
    @Override
    public int hashCode(){
        return Objects.hash(from_vertex, to_vertex);
        
    }
}
