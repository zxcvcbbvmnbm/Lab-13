enum WeightedGraphReturnType
{
	HAS_PATH, GET_MINIMUM_WEIGHT, GET_PATH
}
