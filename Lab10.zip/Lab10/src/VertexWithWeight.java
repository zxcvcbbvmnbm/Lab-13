class VertexWithWeight implements VertexWithWeightFunctions {
	
	public final int vertex;
	public double weight;
	
	VertexWithWeight(int v, double w){
		vertex = v;
		weight = w;
	}
	
	VertexWithWeight(){
		this(0, 0.0);
	}
	
	public int getVertex(){
		return vertex;
	}
	
	public double getWeight(){
		return weight;
	}
	
	public void setWeight(double w){
		weight = w;
	}
	
	public String toString(){
		return "(" + vertex + "," + weight + ")";
	}
	
	public boolean equals(Object other){
		
		if (other == null) return false;
		
		if (this == other) return true;
		
		if (other instanceof VertexWithWeight) {
			
			VertexWithWeight o = (VertexWithWeight) other;
			
			if (vertex == o.vertex) return true;
			
		}
		
		return false;
	}
}