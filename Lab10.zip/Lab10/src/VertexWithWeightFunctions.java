interface VertexWithWeightFunctions
{
	public double getWeight();
	public int getVertex();
	public void setWeight(double w);
	public boolean equals(Object o);
	public String toString();
}