import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.PriorityQueue;

class WeightedGraph implements WeightedGraphFunctions {
	
	private ArrayList <Integer> vertices = new ArrayList <Integer>();
	private ArrayList <EdgeWithWeight> edges = new ArrayList <EdgeWithWeight> ();
	
	private HashSet <Integer> vertex_set = new HashSet <Integer> ();
	private HashSet <EdgeWithWeight> edge_set = new HashSet <EdgeWithWeight> ();
	
	private HashMap <Integer, Integer> vertex_positions = new HashMap<>();
	
	
	
	public boolean addVertex(int v){
		
		if (vertex_set.contains(v)) return false;
		
		
		vertex_positions.put(v, vertices.size());
		vertex_set.add(v);
		vertices.add(v);
		
		return true;
	}
	
	public boolean addWeightedEdge(int from, int to, double weight){
		
		EdgeWithWeight e = new EdgeWithWeight(from, to, weight);
		
		if (edge_set.contains(e)) return false;
		
		if ((!vertex_set.contains(from)) || (!vertex_set.contains(to))) return false;
		
		edge_set.add(e);
		edges.add(e);
		
		return true;
	}
	
	public String toString(){
		
		StringBuilder str = new StringBuilder("G = (V,E)\nV = {");
		
		for (int i=0; i<vertices.size()-1; i++)
			str.append(vertices.get(i) + ",");
		
		str.append(vertices.get(vertices.size()-1) + "}\nE = {");
		
		for (int i=0; i<edges.size()-1; i++)
			str.append(edges.get(i) + ",");
		
		str.append(edges.get(edges.size()-1) + "}");
		
		return str.toString();
	}
	
	public boolean hasPath(int fromVertex, int toVertex){

		if ((!vertex_set.contains(fromVertex)) || (!vertex_set.contains(toVertex)))
			return false;
		
		if (fromVertex == toVertex)
			return true;
		
		return (boolean) getPath(fromVertex, toVertex, WeightedGraphReturnType.HAS_PATH);
	}
	
	public double getMinimumWeight(int fromVertex, int toVertex){
		
		if ((!vertex_set.contains(fromVertex)) || (!vertex_set.contains(toVertex)))
			return Double.NaN;
		
		if (fromVertex == toVertex)
			return 0.0;
		
		return (double) getPath(fromVertex, toVertex, WeightedGraphReturnType.GET_MINIMUM_WEIGHT);
	}
	
	
	public EdgeWithWeight[] getPath(int fromVertex, int toVertex){
		
		if ((!vertex_set.contains(fromVertex)) || (!vertex_set.contains(toVertex)))
			return new EdgeWithWeight[0];
		
		return (EdgeWithWeight []) getPath(fromVertex, toVertex, WeightedGraphReturnType.GET_PATH);
	}

	
	
	public Object getPath(int fromVertex, int toVertex, WeightedGraphReturnType typeOfInfo){
		
		PriorityQueue <VertexWithWeight> minWeight = new PriorityQueue <> (vertices.size(), new VertexWithWeightWeightComparator());
		
		VertexWithWeight [] vww = new VertexWithWeight[vertices.size()];
		
		for (int i=0; i<vertices.size(); i++)
			vww[i] = new VertexWithWeight(vertices.get(i), Double.POSITIVE_INFINITY);
		
		int fromVertexIndex = vertex_positions.get(fromVertex);
		
		vww[fromVertexIndex].setWeight(0);
		
		for (int i=0; i<vertices.size(); i++)
			minWeight.add(vww[i]);
		
		HashMap <Integer, EdgeWithWeight> edge_path = new HashMap <>();
		
		
		
		while (minWeight.size() > 0) {
			
			VertexWithWeight v = minWeight.poll();
			
			if (((Double) v.getWeight()).equals(Double.POSITIVE_INFINITY))
				break;
			
			if (v.getVertex() == toVertex)
				break;
			
			for (EdgeWithWeight e: edges){
				
				if (e.getFromVertex() == v.getVertex()){
					
					int u = e.getToVertex();
					int u_pos = vertex_positions.get(u);
					
					if ((v.getWeight() + e.getWeight()) < vww[u_pos].getWeight()){
						
						minWeight.remove(vww[u_pos]);
						vww[u_pos].setWeight(v.getWeight() + e.getWeight());
						minWeight.add(vww[u_pos]);
						
						edge_path.put(u, e);
					}
				}
			}
		}
		
		
		if (typeOfInfo == WeightedGraphReturnType.HAS_PATH)
			return edge_path.containsKey(toVertex);
		
		if (typeOfInfo == WeightedGraphReturnType.GET_MINIMUM_WEIGHT){
			
			if (edge_path.containsKey(toVertex))
				return (Double) vww[vertex_positions.get(toVertex)].getWeight();
			
			return Double.NaN;
		}
		
		
		if (typeOfInfo == WeightedGraphReturnType.GET_PATH){
			
			if (!edge_path.containsKey(toVertex)) return new EdgeWithWeight[0];
			
			ArrayList <EdgeWithWeight> revPath = new ArrayList <EdgeWithWeight>();
			
			int cur_vertex = toVertex;
			EdgeWithWeight e;
			
			do {
				
				e = edge_path.get(cur_vertex);
				
				revPath.add(e);
				
				cur_vertex = e.getFromVertex();
				
			} while(cur_vertex != fromVertex);
			
			EdgeWithWeight [] path = new EdgeWithWeight[revPath.size()];
			
			for (int i=0; i<revPath.size(); i++)
				path[i] = revPath.get(revPath.size()-1-i);
			
			return path;
		}
		
		
		return null;
	}
	
}













