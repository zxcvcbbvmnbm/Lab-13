import java.util.List;
import java.util.Scanner;

public class MainLab13 {

	public static void main(String[] args) {
		lab13 l13 = new lab13();
		Scanner myObj = new Scanner(System.in); // Create a Scanner object
		System.out.println("Enter filename");//File Name -->lab13_input_data (1).txt
		l13.readData(myObj.nextLine());
		
		
		System.out.println("getTotalCount() : " + l13.getTotalCount());
		System.out.println("getOddCount() : " + l13.getOddCount());
		System.out.println("getEvenCount() : " + l13.getEvenCount());
		System.out.println("getDistinctGreaterThanFiveCount() : " + l13.getDistinctGreaterThanFiveCount());
		System.out.println("Printing data for getResult1() :");
		Integer[] getResult1 = l13.getResult1();		
		for(int i = 0; i<getResult1.length; i++){
			System.out.println(getResult1[i]);
		}
		System.out.println("-----------------------------------");
		System.out.println("Printing data for getResult2() :");
		Integer[] getResult2 = l13.getResult2();		
		for(int i = 0; i<getResult2.length; i++){
			System.out.println(getResult2[i]);
		}
		System.out.println("-----------------------------------");
		System.out.println("Printing data for getResult3() :");
		Integer[] getResult3 = l13.getResult3();		
		for(int i = 0; i<getResult3.length; i++){
			System.out.println(getResult3[i]);
		}
		System.out.println("-----------------------------------");
	}

}
