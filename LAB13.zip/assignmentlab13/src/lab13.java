import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class lab13 {
	final ArrayList<Integer> al = new ArrayList<Integer>();
	
	public void readData(String filename) {
		String path = "C:/Users/admin/eclipse-workspace/assignmentlab13/src/";
		File file = new File(path + filename);
		Scanner scan = null;
		try {
			scan = new Scanner(file);
			while (scan.hasNextLine()) {
				int line = Integer.parseInt(scan.nextLine());							
				al.add(line);				
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			scan.close();
		}
	}
		
	
	public long getTotalCount(){
		return al.stream().count();			
	}
	
	public long getOddCount(){
		return al.stream().filter(x->x%2!=0).count();
	}
	
	public long getEvenCount(){
		return al.stream().filter(x->x%2==0).count();
	}
	
	public long getDistinctGreaterThanFiveCount(){
		return al.stream().filter(x->x>5).distinct().count();
	}
	
	public Integer[] getResult1(){	
        return al.stream().filter(x->x%2==0 && x>5 && x<50).sorted().toArray(Integer[] ::new);
	}
	public Integer[] getResult2(){	
        return al.stream().map(x-> x * x * 3).limit(50).toArray(Integer[] ::new);
	}
	public Integer[] getResult3(){	
        return al.stream().filter(x->x%2!=0).map(x-> x * 2).sorted().skip(20).distinct().toArray(Integer[] ::new);
	}

}
