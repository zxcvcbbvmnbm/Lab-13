
import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.*;


import org.junit.Test;

public class lab13Test {

	@Test
	public void test() {
		lab13 lab13object = new lab13();
		String filename = "lab13_input_data (1).txt";
		lab13object.readData(filename);
		long result= lab13object.getTotalCount();
		assertEquals(1000, result);
		long result2= lab13object.getOddCount();
		assertEquals(507, result2);
		long result3= lab13object.getEvenCount();
		assertEquals(493, result3);
		long result4= lab13object.getDistinctGreaterThanFiveCount();
		assertEquals(94, result4);
		
	}		

}
