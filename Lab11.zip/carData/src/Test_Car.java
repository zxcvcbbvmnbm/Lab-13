import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Iterator;

class Test_Car implements CarFunctions {
	private final String id;
	private final int fuelEconomyInMilesPerGallon;
	private final int fuelCapacityInGallons;
	private double currentFuelInGallons;

	@Override
	public int getFuelEconomyInMilesPerGallon() {
		return fuelEconomyInMilesPerGallon;
	}

	@Override
	public int getFuelCapacityInGallons() {
		return fuelCapacityInGallons;
	}

	@Override
	public double getCurrentFuelInGallons() {
		return currentFuelInGallons;
	}

	@Override
	public String getId() {
		return id;
	}

	@Override
	public void setCurrentFuelInGallons(double v) {
		currentFuelInGallons = v;
	}

	@Override
	public double getTotalRangeInMiles() {
		// TODO Auto-generated method stub
		return CarFunctions.super.getTotalRangeInMiles();
	}

	@Override
	public double getRemainingRangeInMiles() {
		// TODO Auto-generated method stub
		return CarFunctions.super.getRemainingRangeInMiles();
	}

	public Test_Car(String id, int fuelEconomyInMilesPerGallon, int fuelCapacityInGallons,
			double currentFuelInGallons) {
		super();
		this.id = id;
		this.fuelEconomyInMilesPerGallon = fuelEconomyInMilesPerGallon;
		this.fuelCapacityInGallons = fuelCapacityInGallons;
		this.currentFuelInGallons = currentFuelInGallons;
	}

	public String toString() {
		return getId() + "\t" + getFuelEconomyInMilesPerGallon() + "\t" + getFuelCapacityInGallons() + "\t"
				+ getCurrentFuelInGallons() + "\t" + getTotalRangeInMiles() + "\t" + getRemainingRangeInMiles();
	}
}
