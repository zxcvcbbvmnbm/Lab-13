import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collection;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Iterator;

class Test_Name_ManageCarData implements ManageCarDataFunctions {

	ArrayList<CarFunctions> carList;
	PriorityQueue<CarFunctions> carListByTotalRange;
	PriorityQueue<CarFunctions> carListByRemainingRange;

	public Test_Name_ManageCarData() {
		carList = new ArrayList<CarFunctions>();
		carListByTotalRange = new PriorityQueue<CarFunctions>(new TotalRangeComparator());
		carListByRemainingRange = new PriorityQueue<CarFunctions>(new RemainingRangeComparator());
	}

	@Override
	public void readData(String filename) {
		String path = "C:/Users/admin/eclipse-workspace/carData/src/";
		File file = new File(path + filename);
		Scanner scan = null;
		try {
			scan = new Scanner(file);
			while (scan.hasNextLine()) {
				String line = scan.nextLine();
				String[] lineArray = line.split("\\t");
				CarFunctions myCar = new Test_Car(lineArray[0], Integer.parseInt(lineArray[1]),
						Integer.parseInt(lineArray[2]), Double.valueOf(lineArray[3]));
				carList.add(myCar);
				carListByTotalRange.add(myCar);
				carListByRemainingRange.add(myCar);
			}
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} finally {
			scan.close();
		}
	}

	@Override
	public ArrayList<CarFunctions> getCarList() {
		ArrayList<CarFunctions> resultCarList = new ArrayList<CarFunctions>();
		for (CarFunctions value : carList) {
			resultCarList.add(value);
		}
		return resultCarList;
	}

	@Override
	public PriorityQueue<CarFunctions> getCarListByTotalRange() {
		PriorityQueue<CarFunctions> resultCarListByTotalRange = new PriorityQueue<CarFunctions>(
				new TotalRangeComparator());
		for (CarFunctions value : carListByTotalRange) {
			resultCarListByTotalRange.add(value);
		}
		return resultCarListByTotalRange;

	}

	@Override
	public ArrayList<CarFunctions> getCarListByTotalRangeUsingIterator() {
		ArrayList<CarFunctions> resultCarList = new ArrayList<CarFunctions>();
		Iterator value = carListByTotalRange.iterator();
		while (value.hasNext()) {
			resultCarList.add((CarFunctions) value.next());
		}
		return resultCarList;
	}

	@Override
	public PriorityQueue<CarFunctions> getCarListByRemainingRange() {
		PriorityQueue<CarFunctions> resultCarListByRemainingRange = new PriorityQueue<CarFunctions>(
				new RemainingRangeComparator());
		for (CarFunctions value : carListByRemainingRange) {
			resultCarListByRemainingRange.add(value);
		}
		return resultCarListByRemainingRange;
	}

	@Override
	public ArrayList<CarFunctions> getCarListByRemainingRangeUsingIterator() {
		ArrayList<CarFunctions> resultCarList = new ArrayList<CarFunctions>();
		Iterator value = carListByRemainingRange.iterator();
		while (value.hasNext()) {
			resultCarList.add((CarFunctions) value.next());
		}
		return resultCarList;
	}

	@Override
	public ArrayList<String> getCarListByTotalRangeViaPoll(double minTotalRange, double maxTotalRange) {
		ArrayList<String> al = new ArrayList<String>();
		String currentCarString = null;
		PriorityQueue carsByTotalRange = this.getCarListByTotalRange();		
		while( carsByTotalRange.size() > 0 ){
			CarFunctions myCar = (CarFunctions) carsByTotalRange.poll();
			if (myCar.getTotalRangeInMiles() >= minTotalRange && myCar.getTotalRangeInMiles() <= maxTotalRange) {
				currentCarString = myCar.toString();
				for (CarFunctions value : carList) {
					if (value.equals(myCar)) {
						currentCarString.concat("	" + carList.indexOf(myCar));
					}
					if (myCar.getFuelEconomyInMilesPerGallon() == value.getFuelEconomyInMilesPerGallon()) {
						currentCarString.concat("	" + carList.indexOf(myCar));
					}
				}
				/*
				 * for (CarFunctions value : carList) { if
				 * (myCar.getFuelEconomyInMilesPerGallon() ==
				 * value.getFuelEconomyInMilesPerGallon()) {
				 * currentCarString.concat("	" + carList.indexOf(myCar)); } }
				 */
			}
			al.add(currentCarString);
		}
		/*for (CarFunctions value : carList) {
			carListByTotalRange.add(value);
		}*/
		return al;
	}

	@Override
	public ArrayList<String> getCarListByRemainingRangeViaPoll(double minRemainingRange, double maxRemainingRange) {
		ArrayList<String> al = new ArrayList<String>();
		String currentCarString = null;
		PriorityQueue carsByRemainingRange = this.getCarListByRemainingRange();
		while(carsByRemainingRange.size() > 0 ){
			CarFunctions myCar = (CarFunctions) carsByRemainingRange.poll();
			if (myCar.getRemainingRangeInMiles() >= minRemainingRange && myCar.getRemainingRangeInMiles() <= maxRemainingRange) {
				currentCarString = myCar.toString();
				for (CarFunctions value : carList) {
					if (value.equals(myCar)) {
						currentCarString.concat("\t" + carList.indexOf(myCar));
					}
					if (myCar.getFuelEconomyInMilesPerGallon() == value.getFuelEconomyInMilesPerGallon()) {
						currentCarString.concat("\t" + carList.indexOf(myCar));
					}
				}
				/*
				 * for (CarFunctions value : carList) { if
				 * (myCar.getFuelEconomyInMilesPerGallon() ==
				 * value.getFuelEconomyInMilesPerGallon()) {
				 * currentCarString.concat("	" + carList.indexOf(myCar)); } }
				 */
			}
			al.add(currentCarString);
		}
		/*for (CarFunctions value : carList) {
			carListByRemainingRange.add(value);
		}*/
		return al;
	}

}
