import java.util.ArrayList;
import java.util.PriorityQueue;
import java.util.Scanner;
import java.util.Iterator;

class testCarData
{
	public static void main(String[] args)
	{
		/*if( args.length != 5 )
		{
			System.out.println("format testCarData \"input file\" \"min total range\" \"max total range\" \"min remaining range\" \"max remaining range\"");
			System.exit(0);
		}*/
		 Scanner myObj = new Scanner(System.in);  // Create a Scanner object
		 System.out.println("Enter filename"); // sample_data3.txt / sample_data.txt / sample_data2.txt
		 String filename = myObj.nextLine();  // Read user input
		 System.out.println("Enter minTotalRange"); // 1.0
		 double minTotalRange = Double.parseDouble(myObj.nextLine());  // Read user input
		 System.out.println("Enter maxTotalRange"); // 9999.0
		 double maxTotalRange = Double.parseDouble(myObj.nextLine());  // Read user input
		 System.out.println("Enter minRemainingRange"); // 1.0
		 double minRemainingRange = Double.parseDouble(myObj.nextLine());  // Read user input
		 System.out.println("Enter maxRemainingRange"); // 9999.0
		 double maxRemainingRange = Double.parseDouble(myObj.nextLine());  // Read user input
		
		// get the command line arguments
		//String filename = "sample_data3.txt";
		//double minTotalRange = 1.0;
		//double maxTotalRange = 9999.0;
		//double minRemainingRange = 1.0;
		//double maxRemainingRange = 9999.0;
		
		// create a ManageCarData object
		ManageCarDataFunctions manageCarData = new Test_Name_ManageCarData();
		
		// read the car definitions from the input file
		manageCarData.readData(filename);
		
		// get the list of cars that is stored as an arraylist and print it out
		System.out.println("carList");
		ArrayList<CarFunctions> carList = manageCarData.getCarList();
		for( CarFunctions c : carList )
		{
			System.out.println(c);
		}
		System.out.println();

		// get the list of cars stored in the PriorityQueue ordered by total range via an iterator and print it out
		System.out.println("carListByTotalRange iterator");
		ArrayList<CarFunctions> carListByTotalRangeByIterator = manageCarData.getCarListByTotalRangeUsingIterator();
		for( CarFunctions c : carListByTotalRangeByIterator )
		{
			System.out.println(c);
		}
		System.out.println();
		
		// get an iterator for the PriorityQueue ordered by total range and print them out
		System.out.println("carListByTotalRange iterator local");
		Iterator<CarFunctions> itByTotalRange = manageCarData.getCarListByTotalRange().iterator();
		while( itByTotalRange.hasNext() )
		{
			System.out.println(itByTotalRange.next());
		}
		System.out.println();
		
		// get the list of cars stored in the PriorityQueue ordered by remaining range via an iterator and print it out
		System.out.println("carListByRemainingRange iterator");
		ArrayList<CarFunctions> carListByRemainingRangeByIterator = manageCarData.getCarListByRemainingRangeUsingIterator();
		for( CarFunctions c : carListByRemainingRangeByIterator )
		{
			System.out.println(c);
		}
		System.out.println();
		
		// get an iterator for the PriorityQueue ordered by remaining range and print them out
		System.out.println("carListByRemainingRange iterator local");
		Iterator<CarFunctions> itByRemaininglRange = manageCarData.getCarListByRemainingRange().iterator();
		while( itByRemaininglRange.hasNext() )
		{
			System.out.println(itByRemaininglRange.next());
		}
		System.out.println();
		
		// get the list of cars stored in the PriroityQueue ordered by total range having total range [minTotalRange, maxTotalRange]
		System.out.println("carListByTotalRange.poll().getTotalRangeInMiles() in [" + minTotalRange + "," + maxTotalRange + "]");
		ArrayList<String> carListByTotalRangeByPoll = manageCarData.getCarListByTotalRangeViaPoll(minTotalRange, maxTotalRange);
		for( String s : carListByTotalRangeByPoll )
		{
			System.out.println(s);
		}
		System.out.println();
		
		// get the list of cars stored in the PriroityQueue ordered by remaining range having total range [minRemainingRange, maxRemainingRange]
		System.out.println("carListByTotalRange.poll().getRemainingRangeInMiles() in [" + minRemainingRange + "," + maxRemainingRange + "]");
		ArrayList<String> carListByRemainingRangeByPoll = manageCarData.getCarListByRemainingRangeViaPoll(minRemainingRange, maxRemainingRange);
		for( String s : carListByRemainingRangeByPoll )
		{
			System.out.println(s);
		}
		System.out.println();
		
		// get the list of cars stored in the PriorityQueue ordered by total range via an iterator and print it out
		System.out.println("carListByTotalRange iterator (if empty, you didn't refill carListByTotalRange after polling all of the elements)");
		carListByTotalRangeByIterator = manageCarData.getCarListByTotalRangeUsingIterator();
		for( CarFunctions c : carListByTotalRangeByIterator )
		{
			System.out.println(c);
		}
		System.out.println();
		
		// get the list of cars stored in the PriorityQueue ordered by remaining range via an iterator and print it out
		System.out.println("carListByRemainingRange iterator (if empty, you didn't refill carListByRemainingRange after polling all of the elements)");
		carListByRemainingRangeByIterator = manageCarData.getCarListByRemainingRangeUsingIterator();
		for( CarFunctions c : carListByRemainingRangeByIterator )
		{
			System.out.println(c);
		}
		System.out.println();

	}
}
